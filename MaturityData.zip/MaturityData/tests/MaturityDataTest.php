<?php

use PHPUnit\Framework\TestCase;

final class MaturityDataTest extends TestCase
{
	
    public function testPolicyType(){
    	$maturityTestData = new MaturityData("A100001", "01/06/1986", 10000, "Y", 1000, 40);	
				
        $this->assertEquals(
            'A',
            $maturityTestData->policyType()
		);
    }
	
	public function testManagementFeePercent(){
    	$maturityTestData = new MaturityData("A100001", "01/06/1986", 10000, "Y", 1000, 40);	
		$this->assertEquals(
            0.03,
            $maturityTestData->managementFeePercent()
		);
    }
	public function testisDateBeforeCutOff(){
    	$maturityTestData = new MaturityData("A100001", "01/06/1986", 10000, "Y", 1000, 40);	
		$this->assertEquals(
            1,
            $maturityTestData->isDateBeforeCutOff()
		);
    }	
	public function testmembershipRights(){
    	$maturityTestData = new MaturityData("A100001", "01/06/1986", 10000, "Y", 1000, 40);	
		$this->assertEquals(
            1,
            $maturityTestData->membershipRights()
		);
    }		
	public function testactualDiscretionaryBonus(){
    	$maturityTestData = new MaturityData("A100001", "01/06/1986", 10000, "Y", 1000, 40);	
		$this->assertEquals(
            1000,
            $maturityTestData->actualDiscretionaryBonus()
		);
    }
	public function testmaturityValue(){
    	$maturityTestData = new MaturityData("A100001", "01/06/1986", 10000, "Y", 1000, 40);	
		$this->assertEquals(
            14980,
            $maturityTestData->maturityValue()
		);
    }			
			
}


?>