---READ ME---

MaturityData.php - takes the policy input and calculates the maturity value.
MaturityData.xml - Policy Number and corresponding Maturity Value output.
MaturityDataTest.php - code for a Unit Test

The Unit Test was carried out with PHPUnit (which can be downloaded from https://phpunit.de)

To run the test:

phpunit --bootstrap src/MaturityData.php tests/MaturityDataTest





_____
U.I.