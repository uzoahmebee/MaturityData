<!DOCTYPE html>
<html lang="en">
<head></head>
<body>
<?php

/**
 *  MaturityData.php - takes the policy input and calculates the maturity value.
 */
 
/**
 * class MaturityData - MaturityData object
 */
class MaturityData{
	public $policyNumber;
	public $policyStartDate;
	public $premium;
	public $membership;
	public $discretionaryBonus;	
	public $upliftPercentage;
	
  /**
  * MaturityData constructor - Instantiates a new MaturityData object
  *
  * @param string $policyNumber
  * @param string $policyStartDate
  * @param int $premium
  * @param string $membership
  * @param int $discretionaryBonus
  * @param int $upliftPercentage
  * 
  * @return void
  */
	public function __construct($policyNumber, $policyStartDate, $premium, $membership, $discretionaryBonus, $upliftPercentage){
		$this->policyNumber = $policyNumber;
		$this->policyStartDate = $policyStartDate;
		$this->premium =$premium;
		$this->membership =$membership;
		$this->discretionaryBonus =$discretionaryBonus;
		$this->upliftPercentage =$upliftPercentage;
	}

  /**
  * policyType - Returns the first character of the policy number
  *
  * @param string $policyNumber
  *
  * @return char
  */		
	public function policyType(){
		$array = str_split($this->policyNumber);
		return $array[0];
		}

  /**
  * managementFeePercent function -  Returns the management fee percentage (in decimal form)
  *
  * @param string policyType()
  *
  * @return double
  */		
	public function managementFeePercent(){
		if (strcmp($this->policyType(), "A") == 0) {
			return 0.03;
		}
		else	if (strcmp($this->policyType(), "B") == 0) {
			return 0.05;
		}
		else	if (strcmp($this->policyType(), "C") == 0) {
			return 0.07;
		}	
	}	

  /**
  * isDateBeforeCutOff function -  Confirms whether or not the policy date is on or before the cut-off date (01/01/1990)
  *
  * @param string policyStartDate
  *
  * @return boolean
  */	
	public function isDateBeforeCutOff(){
		$cutOffString = "01/01/1990";
		$cutOffDate = DateTime::createFromFormat('d/m/Y', $cutOffString);
		$cutOffDateFormatted = $cutOffDate->format ('d/m/y');
				
		$policyDateString =  $this->policyStartDate;
		$policyDate = DateTime::createFromFormat('d/m/Y', $policyDateString);
		$policyDateFormatted  = $policyDate->format ('d/m/y');
		
		$interval = $cutOffDate->diff($policyDate);
		
		$formatedDifference = $interval->format("%R%a");
		
		if ($formatedDifference < 0){
			return TRUE;
		}
		
		else {
			return FALSE;
		}
	}	

  /**
  * membershipRights function -  Confirms whether or not the policy confers membership rights, Y=Yes, N=No. 
  *
  * @param string $membership
  *
  * @return boolean
  */		
	public function membershipRights(){
		if (strcmp($this->membership, "Y") == 0) {
			return TRUE;
		}
		else	if (strcmp($this->membership, "N") == 0) {
			return FALSE;
		}
		else{
			die ('Invalid membership rights');
		}	
	}
		
  /**
  * actualDiscretionaryBonus function -  Returns the value of a one-off cash bonus which will be applied based on certain criteria 
  *
  * @param string $discretionaryBonus
  *
  * @return int
  */		
	public function actualDiscretionaryBonus(){
	
		if ((strcmp($this->policyType(), "A") == 0) & ($this->isDateBeforeCutOff()== TRUE)){
			return $this->discretionaryBonus;
		}
		else if ((strcmp($this->policyType(), "B") == 0) & ($this->membershipRights()== TRUE)){
			return $this->discretionaryBonus;
		}	
		else if ((strcmp($this->policyType(), "C") == 0)& ($this->isDateBeforeCutOff()== FALSE) & ($this->membershipRights()== TRUE)){
			return $this->discretionaryBonus;
		}	
		
		else return 0;
	}			

  /**
  * maturityValue function -  Confirms whether or not a one-off cash bonus will be applied based on certain criteria 
  *
  * @param int $premium
  * @param double managementFeePercent()
  * @param int actualDiscretionaryBonus()
  * @param int $upliftPercentage
  * 
  * @return int
  */				
	public function maturityValue(){
		
		$totalMaturityValue = ( ($this->premium - ($this->premium * $this->managementFeePercent()) ) + $this ->actualDiscretionaryBonus() )* ( 1 + ( ($this->upliftPercentage) / 100 ));
		
		return $totalMaturityValue;
		}	  
	}

	$file = fopen("MaturityData.csv","r")  or die("Unable to open input file!"); 
	fgets($file);
	
	$fileOutput = fopen("MaturityData.xml","w")  or die("Unable to open output file!"); 
	fwrite($fileOutput, "<MaturityData>");
	
	while(!feof($file)) {
		$chunk =  fgetcsv($file);
		 
		$maturityDataRow = new MaturityData($chunk[0], $chunk[1], $chunk[2], $chunk[3], $chunk[4], $chunk[5]);
	
		   if ($maturityDataRow->policyNumber == NULL){
		   		break;
		   }
		
		   else{
			 	fwrite($fileOutput, "<policy id = \"" .$maturityDataRow->policyNumber . "\" ><MaturityValue>" . $maturityDataRow->maturityValue() ."</MaturityValue> </policy>");
		   }
	}
	
	fwrite($fileOutput, "</MaturityData>");
	fclose($file);
	fclose($fileOutput);
	
	echo "Output written to MaturityData.xml";
?>

</body>
</html>